<?php
	include_once '../includes/db_connect.php';
	include_once 'stock_functions.php';

	echo xml2db("stock.xml",$con);
?>