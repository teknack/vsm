<?php
if(class_exists('Memcached')){
  echo "Memcached exists";
}
else{
	echo "Memcached doesn't exists";
}
?>